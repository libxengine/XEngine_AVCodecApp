﻿#pragma once
/********************************************************************
//    Created:     2024/03/29  16:48:02
//    File Name:   D:\XEngine\XEngine_SourceCode\XEngine_HelpComponents\HelpComponents_WBlackList\WBlackList_Error.h
//    File Path:   D:\XEngine\XEngine_SourceCode\XEngine_HelpComponents\HelpComponents_WBlackList
//    File Base:   WBlackList_Error
//    File Ext:    h
//    Project:     XEngine(网络通信引擎)
//    Author:      qyt
//    Purpose:     黑白名单列表模块导出错误
//    History:
*********************************************************************/
//////////////////////////////////////////////////////////////////////////
//                       IPV4黑名单错误表
//////////////////////////////////////////////////////////////////////////
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_PARAMENT 0x50A0001       //参数错误
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_MALLOC 0x50A0002         //申请内存失败
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_NOTFOUND 0x50A0003       //没有找到指定句柄
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_ISEXIST 0x50A0004        //添加的黑名单已经存在了
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_ADDRSTART 0x50A0005      //解析开始地址失败
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_ADDREND 0x50A0006        //解析结束地址失败
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_NOTSUPPORT 0x50A0007     //不支持的通配符方式
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_ALLNONE 0x50A0008        //全部为过滤,这个设置没有任何效果
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_RANGE 0x50A0009          //在范围内
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_ISNULL 0x50A0010         //列表为空
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_NOTIPADDR 0x50A0011      //不是标准的IP地址
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV4ADDR_NOTEXIST 0x50A0012       //这个IP地址不存在
//////////////////////////////////////////////////////////////////////////
//                       域名黑名单错误表
//////////////////////////////////////////////////////////////////////////
#define ERROR_HELPCOMPONENTS_WBLACKLIST_DOMAINADDR_PARAMENT 0x50A1001     //参数错误
#define ERROR_HELPCOMPONENTS_WBLACKLIST_DOMAINADDR_MALLOC 0x50A1002       //申请内存失败
#define ERROR_HELPCOMPONENTS_WBLACKLIST_DOMAINADDR_NOTFOUND 0x50A1003     //没有找到句柄
#define ERROR_HELPCOMPONENTS_WBLACKLIST_DOMAINADDR_ISEXIST 0x50A1004      //已经存在于黑名单
#define ERROR_HELPCOMPONENTS_WBLACKLIST_DOMAINADDR_ISNULL 0x50A1005       //黑名单列表为空
#define ERROR_HELPCOMPONENTS_WBLACKLIST_DOMAINADDR_NOTEXIST 0x50A1006     //不存在黑名单
#define ERROR_HELPCOMPONENTS_WBLACKLIST_DOMAINADDR_NOTDOMAIN 0x50A1007    //这个域名不正确
//////////////////////////////////////////////////////////////////////////
//                       IPV4黑名单错误表
//////////////////////////////////////////////////////////////////////////
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_PARAMENT 0x50A2001       //参数错误
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_MALLOC 0x50A2002         //申请内存失败
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_NOTFOUND 0x50A2003       //没有找到指定句柄
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_ISEXIST 0x50A2004        //添加的黑名单已经存在了
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_ADDRSTART 0x50A2005      //解析开始地址失败
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_ADDREND 0x50A2006        //解析结束地址失败
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_NOTSUPPORT 0x50A2007     //不支持的通配符方式
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_ALLNONE 0x50A2008        //全部为过滤,这个设置没有任何效果
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_EXIST 0x50A2009          //已经存在
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_RANGE 0x50A2010          //在范围内
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_ISNULL 0x50A2011         //列表为空
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_NOTIPADDR 0x50A2012      //不是标准的IP地址
#define ERROR_HELPCOMPONENTS_WBLACKLIST_IPV6ADDR_NOTEXIST 0x50A2013       //这个IP地址不存在