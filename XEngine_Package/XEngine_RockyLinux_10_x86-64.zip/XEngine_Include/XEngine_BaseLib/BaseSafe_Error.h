﻿#pragma once
/********************************************************************
//    Created:     2024/06/19  15:17:53
//    File Name:   D:\XEngine\XEngine_SourceCode\XEngine_BaseLib\XEngine_BaseSafe\BaseSafe_Error.h
//    File Path:   D:\XEngine\XEngine_SourceCode\XEngine_BaseLib\XEngine_BaseSafe
//    File Base:   BaseSafe_Error
//    File Ext:    h
//    Project:     XEngine(网络通信引擎)
//    Author:      qyt
//    Purpose:     基础安全操作函数错误码
//    History:
*********************************************************************/
/************************************************************************/
/*                         字符串安全操作                               */
/************************************************************************/
#define ERROR_XENGINE_BASELIB_SAFE_STRING_PARAMENT 0x10C0001            //参数错误
#define ERROR_XENGINE_BASELIB_SAFE_STRING_LEN 0x10C0002                 //长度错误
/************************************************************************/
/*                         内存安全操作                                 */
/************************************************************************/
#define ERROR_XENGINE_BASELIB_SAFE_MEMORY_PARAMENT 0x10C1001            //参数错误
#define ERROR_XENGINE_BASELIB_SAFE_MEMORY_LEN 0x10C1002                 //长度错误
/************************************************************************/
/*                         文件安全操作                                 */
/************************************************************************/
#define ERROR_XENGINE_BASELIB_SAFE_FILE_PARAMENT 0x10C2001             //参数错误
#define ERROR_XENGINE_BASELIB_SAFE_FILE_OPEN 0x10C2002                 //打开失败
#define ERROR_XENGINE_BASELIB_SAFE_FILE_CREATE 0x10C2003               //创建失败
#define ERROR_XENGINE_BASELIB_SAFE_FILE_SIZE 0x10C2004                 //获取大小错误
#define ERROR_XENGINE_BASELIB_SAFE_FILE_MALLOC 0x10C2005               //申请内存失败